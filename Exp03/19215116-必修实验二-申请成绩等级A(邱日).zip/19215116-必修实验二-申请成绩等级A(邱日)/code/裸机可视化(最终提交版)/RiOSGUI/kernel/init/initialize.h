/*
 *  RiOS/init/initialize.h
 *
 *  (C) 2017  Curie （邱日）
 */

int initialize();
